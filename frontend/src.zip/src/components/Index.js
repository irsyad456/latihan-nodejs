import { Link } from "react-router-dom"

const Index = () => {

    return (
        <nav class="navbar" role="navigation" aria-label="main navigation">
            <div class="navbar-brand">
                <a class="navbar-item" href="https://bulma.io">
                    <img src="https://bulma.io/images/bulma-logo.png" width="112" height="28" />
                </a>

                <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                    <span aria-hidden="true"></span>
                </a>
            </div>

            <div id="navbarBasicExample" class="navbar-menu">
                <div class="navbar-start">
                    <Link to='/' className="navbar-item">Home</Link>
                    <Link to='/masyarakat' className="navbar-item">Masyarakat</Link>
                    <Link to='/pengaduan' className="navbar-item">pengaduan</Link>
                    <Link to='/petugas' className="navbar-item">Petugas</Link>
                    <Link to='/tanggapan' className="navbar-item">Tanggapan</Link>

                    {/* <div class="navbar-item has-dropdown is-hoverable">
                        <a class="navbar-link">
                            More
                        </a>

                        <div class="navbar-dropdown">
                            <a class="navbar-item">
                                About
                            </a>
                            <a class="navbar-item">
                                Jobs
                            </a>
                            <a class="navbar-item">
                                Contact
                            </a>
                            <hr class="navbar-divider" />
                            <a class="navbar-item">
                                Report an issue
                            </a>
                        </div>
                    </div> */}
                </div>

                {/* <div class="navbar-end">
                    <div class="navbar-item">
                        <div class="buttons">
                            <a class="button is-primary">
                                <strong>Sign up</strong>
                            </a>
                            <a class="button is-light">
                                Log in
                            </a>
                        </div>
                    </div>
                </div> */}
            </div>
        </nav>
        // <div className="dropdown is-active">
        //     <div className="dropdown-trigger">
        //         <button className="button" aria-haspopup="true" aria-controls="dropdown-menu">
        //             <span>Link</span>
        //             <span className="icon is-small">
        //                 <i className="fa fa-angle-down" aria-hidden="true"></i>
        //             </span>
        //         </button>
        //     </div>
        //     <div className="dropdown-menu" id="dropdown-menu" role="menu">
        //         <div className="dropdown-content">
        //             <Link to={'/pengaduan'} className="dropdown-item">List Pengaduan</Link>
        //             <Link to={'/masyarakat'} className="dropdown-item">List Masyarakat</Link>
        //             <Link to={'/petugas'} className="dropdown-item">List Petugas</Link>
        //             <Link to={'/tanggapan'} className="dropdown-item">List Tanggapan</Link>
        //             <a className="dropdown-item"></a>
        //         </div>
        //     </div>
        // </div>

    )
}

export default Index